# Fixer comment templates

## Inline thread reply (after successful fix)

Fixed in `<sha>`. Root cause: `<specific race/contract/condition>`. The change `<what and where>`; regression coverage: `<test name, executed result or not run>`. I verified `<what was actually checked>`.

If not fixed: `Status: <already fixed / not reproducible / blocked / needs decision>. Evidence: <current HEAD and relevant code path>. No new fix was pushed for this item.`

## One top-level PR Conversation comment

### Review findings repair report

**Base inspected:** `<initial HEAD sha>`
**Final HEAD:** `<final HEAD sha or unchanged>`
**Commits pushed:** `<commit urls, or none>`

| Finding / thread | Result | Evidence |
| --- | --- | --- |
| `<thread ID or URL>` | `fixed / already fixed / not reproducible / blocked / needs decision` | `<file, SHA, test>` |

**Local verification:**
- `<actual command>` — `<actual status/count>`

**Not verified / blockers:** `<runtime constraints, CI not run, browsers not tested>`
**CI:** `Not manually triggered. <Effect of push on automatic workflows if known; never promise no trigger without evidence>.`

**Follow-up:** `<remaining items or no known open items>`

Never fabricate a commit SHA, test count, comment link, or success status. If nothing was pushed, title the comment `Review findings triage (no new commit)` instead of calling it a completed repair.

## User-facing final handoff

- PR URL and verified final HEAD
- Status per finding; code changes and pushed SHA(s)
- Reply/report links when tool responses provide them
- Tests actually run vs unavailable
- CI behavior and unresolved blockers
