# PR Fixer: Safe Change Protocol

## Preflight

- Capture `repository_full_name`, `head_repo_full_name`, `head` branch, exact `head_sha`, `base_sha`, PR state and repository permissions. Distinguish branch name from SHA.
- Check relevant source at HEAD and any affected generated/lock files. Read `AGENTS.md`, project scripts, and local test instructions.
- Fetch all open threads and relevant prior replies, not just the latest top-level comment.
- Check whether the requested fix is already present or the thread concerns an older commit.
- Never edit the default branch while intending to fix an existing PR.

## Changes

- Prefer a single commit for the verified issue set. Avoid concurrent writes to the same file.
- Prefer local patch/tests and a single `git push` when terminal and permissions exist.
- For GitHub Git objects, create all updated blobs/tree against the verified base tree, create a commit with the exact old HEAD as parent, then `update_ref` for the head repository's branch with `force=false`, `expected_sha=<old head>`; confirm result and current PR HEAD.
- If a ref update is rejected because HEAD changed, abort and rebase/re-evaluate. Do not retry with `force=true`.
- If the PR is from a fork, first establish that the authorized identity can write the fork head. Do not push to a same-named branch in the upstream repo.
- Only if a single atomic commit is unavailable, use supported contents API with explicit branch and fresh blob SHA; disclose the multi-commit/CI implication beforehand.

## CI and validation

- Default to no manual CI dispatch or re-run and local-only verification. Before any push, inspect branch-triggered workflows and policies.
- `git commit -m '... [skip ci]'` / a GitHub skip directive may skip some `push` or `pull_request` workflows but not all events. It can leave required status checks pending. A push itself can trigger CI even if no dispatch tool is called.
- If the user requires *zero* CI runs and safe suppression is unverified, stop before the push and explain the blocker. Do not claim guaranteed no CI merely because a skip token was included.
- Distinguish: commands actually executed, existing CI logs merely read, static analysis, mock DOM tests, native-browser tests and unverified steps. Record counts and failures.
- Avoid secret-bearing output, arbitrary generated changes, formatting unrelated files, workflow config changes, and dependency upgrades not required by the fix.

## Review-thread and reporting rules

- Use inline review comment reply API with the thread's original top-level numeric comment ID (not a reply-to-reply ID) when available.
- For a fixed issue, explain cause and fix, and reference the SHA and regression test. For a false positive, explain the factual counterexample. For a deferred issue, explain blocker and follow-up.
- Do not auto-resolve threads unless the user explicitly authorizes resolution and the fix is verified.
- Before posting, check for an identical earlier repair reply/report on the same SHA to avoid duplicates.
- Do not post a final *completed* repair report if code remains unpushed or validation requirements are unmet; post a clearly marked partial/blocked status only when appropriate.
