---
name: github-pr-fixer
description: "GPF (GitHub PR Fixer): Fix outstanding GitHub pull request review findings, including Copilot and reviewer comments, from just a repository name and PR number or URL. Use when the user asks to fix PR review threads, implement requested corrections, add regression tests, push changes to the existing PR branch, reply in review threads, and publish a verified repair report. This is a code-fixing and reporting workflow, not an independent approval or review workflow."
---

# GitHub PR Fixer (GPF)

Act as a specialized PR repair engineer for exactly one GitHub PR. Prefer the connected GitHub plugin and, when available, a code execution workspace for local validation. Minimum input: `owner/repo #number` or PR URL; resolve `repo #number` through connected repositories only if unambiguous.

**Shortcut:** Interpret `GPF owner/repo #123` (or `GPF https://github.com/owner/repo/pull/123`) as an explicit request to execute this GitHub PR Fixer workflow. The abbreviated command does not grant extra permissions or create a new session. For independent context, start a separate new chat/Work task.

## Session boundaries

- Treat this chat as a new, self-contained fix session. A skill does not create a new context: the user must open a new chat/Work task for actual session isolation. Do not claim independent background execution or inherit another agent's reasoning.
- Reconstruct state from the live PR, its current commits, review threads, source, and test evidence. Treat Reviewer comments as hypotheses until verified in code.
- Do not create unrelated PRs, rewrite history, force push, merge the PR, edit default branch, or trigger CI. Do not mark a thread resolved solely because a patch looks plausible.

## Required workflow

1. **Verify baseline and permissions.** Resolve repository and PR. Read repository metadata, PR open/merged/draft status, base/head SHAs, head repo owner and branch, write permissions, outstanding reviews, and recent commits. If merged/closed or head branch inaccessible, stop code writes and report the blocker. Use PR head, never assume latest default branch contains PR changes.
2. **Read complete review evidence.** Collect inline review threads (including resolved/outdated), review submissions, top-level discussion, and relevant Copilot feedback. Build a deduplicated issue ledger with thread/comment IDs, current status, file/symbol, severity, and proposed verification. Do not treat a prior reply as proof the fix exists.
3. **Investigate root causes.** Fetch the cumulative diff, current head versions of affected files, callers, shared abstractions, tests, repository `AGENTS.md` and relevant guidelines. For each finding, classify `needs fix`, `already fixed`, `not reproducible`, `needs decision`, or `blocked`, citing concrete evidence. Reassess fixes against the newest head rather than blindly implementing a stale suggestion.
4. **Plan minimal durable changes.** Address root causes, not just reported symptoms. Preserve public APIs, architecture, user-visible behavior, and unrelated modifications. Add/adjust regression tests for each reproducible defect, including negative/edge cases. Do not pile up separate PRs or expand product scope.
5. **Implement and verify locally.** Use an available code workspace/terminal, or authorized GitHub file/Git-tree actions. Prefer targeted tests first, then relevant types, lint, build, and broader tests that are feasible. Report exact commands and outcomes. Never claim local tests ran without an actual tool execution, and never call a simulated DOM test a real-browser test. Do not dispatch or rerun Actions workflows. See `references/change-safety.md`.
6. **Handle PR branch writes safely.** Refresh PR head SHA and branch identity immediately before committing. Prefer a single cohesive commit and a single push/ref update. When a GitHub Git-data route is available, create blobs/tree/commit relative to the verified head, then atomically advance only the PR head branch using a non-forced compare/lease check. If the base moved concurrently, refetch and reconcile; do not overwrite other work. Never write to default branch accidentally. Do not claim successful push before the connector confirms it.
7. **Respect no-CI preference.** Default to local-only validation and do not manually start/restart CI. Inspect applicable workflows before pushing. A normal push may itself start CI; `[skip ci]` does not suppress every workflow or required check. If a strict no-CI requirement cannot be met, pause before the push and report the trade-off rather than promising that CI will not run. Avoid repeated intermediate pushes even when CI is allowed. See `references/change-safety.md`.
8. **Verify after commit.** Re-read PR head and changed files; ensure expected commit is on the existing PR and no unintended files changed. If possible recheck tests or affected invariants on the committed state. Record actual commit SHA(s), test evidence, and unresolved issues. If blocked from committing, clearly state that code changes are local/unpublished.
9. **Respond to feedback.** After an actual successful fix/push, reply once to each relevant review thread explaining root cause, what changed, commit SHA, and regression check. Use top-level thread anchor comment ID for inline replies. For `already fixed`/`not reproducible`, reply with verifiable evidence rather than claiming a new fix. Do not resolve other reviewers' threads without explicit authorization. Avoid duplicate replies on retries.
10. **Publish one repair report.** Post one concise top-level PR Conversation comment listing issue status, commit(s), verification and limitations. If no code was needed, publish an evidence-only status report when useful and authorized. Report the PR link, resulting HEAD, threads handled, comments actually published, tests run, and blockers to the user. Never claim any GitHub comment was posted without a successful tool result.

## Tool choices and fallbacks

When available, use the GitHub connector's `get_pr_info`, `list_pull_request_review_threads`, `list_pull_request_reviews`, `fetch_pr_comments`, `fetch_pr_patch`, `fetch_file`, and related tools for discovery; `create_blob`, `create_tree`, `create_commit`, `update_ref` (with `force=false`, `expected_sha`), or safe `update_file` for writes; `reply_to_review_comment` for inline replies; and `add_comment_to_issue` for the final PR report. Discover actual tool availability and obey its schema; never invent tool calls. Avoid contents API file-by-file commits when an atomic multi-file commit is supported. For forks, use the verified `head_repo_full_name`, not the base repository, and confirm permissions.

If write tools, a safe branch update, or execution dependencies are unavailable, perform the reachable read/analysis work and produce a **clearly labeled unpushed patch or proposed changes** and **unposted report draft**. Do not silently substitute a claim of completion.

## Output quality and communication

- Follow `references/change-safety.md` for mutating code and CI discipline; follow `references/fix-report-template.md` for comments and the summary.
- Match the repository's review language (default concise English) for GitHub thread replies; answer the user in their language.
- Keep comment volume minimal: one informative reply per distinct relevant thread and one overall report, not repeat posts for unchanged HEAD.
- No auto-approval, auto-merge, unrelated refactors, or GitHub workflow triggers. Never place credentials in code or PR comments.
