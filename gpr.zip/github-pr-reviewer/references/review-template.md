# GitHub review publication

Prefer one GitHub review action with targeted inline findings and this concise body:

## PR review (HEAD `<short-sha>`)

**Scope:** `<key paths / changes and historical fix commits reviewed>`
**Findings:** `<P0 count> P0, <P1 count> P1, <P2 count> P2, <P3 count> P3`

- `<one-line finding + path, if not already in an inline comment>`
- `<one-line finding + path>`

**Verification:** `<only tests actually executed; identify local, simulated or real browser>`
**Limits:** `<coverage gaps, missing runtime, or unresolved uncertainty>`

If no actionable findings: `No new actionable findings identified in the reviewed scope; this is a comment review, not an approval.`

User-facing result: `PR URL | reviewed HEAD | GitHub review publication succeeded/failed | findings | verification | remaining uncertainty`.

Never announce review publication before the API confirms success. Do not post multiple duplicate summary reviews on repeated runs with an unchanged HEAD and findings.
