# PR Review Standards

## Triage and evidence

1. Read current code before deciding a historical comment remains valid.
2. Focus on newly introduced issues, uncorrected prior issues, and regressions caused by recent repair commits.
3. Link behavior to a concrete execution path, realistic input, race ordering, or invariant violation. Do not report a hypothetical issue without a credible path to impact.
4. Check existing guards, call sites, tests, and serialization boundaries before asserting a defect.
5. A test not run is not a passing test. A simulated DOM test is not a real-browser test. If CI history is checked, report it as preexisting CI results, not as your own test run.
6. Separate observable evidence from an assumption and mark the assumption explicitly.

## Severity rubric

- `P0`: Immediate catastrophic impact such as unbounded data loss, security compromise, or major production outage; strong evidence required.
- `P1`: High-likelihood or high-impact functional failure, security issue, corruption, or significant regression.
- `P2`: Meaningful behavior failure in a narrower circumstance or an important missing regression guard.
- `P3`: Minor bug or maintainability concern with clear user/developer impact. Avoid pure style nits.

## Edge-case checklist (apply selectively)

- Async lifecycle: stale promises, abort, rerenders, reused identifiers, out-of-order saves, navigation or close races, and error recovery.
- State integrity: ownership, revision/version guards, persistence atomicity, rollback, idempotency, undo/redo integrity.
- Runtime correctness: type and null boundaries, resource cleanup, network errors, malformed input, time and timezone handling.
- UI: keyboard/mobile interaction, orientation, scaling, accessibility, and actual rendering behaviors.
- Tests: correct intent, fail-before/pass-after evidence, realistic fixtures, browser-vs-mock distinction.
- Security: exposed secrets, authorization, injection, CSRF, data exfiltration, unsafe path handling.
- CI: do not trigger, rerun, or dispatch workflows; do not mistake a status badge for local verification.

## Inline review comment quality

Format: `[P1] Short imperative/problem title`. Explain:

- Trigger: when/how the defect occurs.
- Effect: precisely what breaks.
- Fix direction: smallest durable fix or invariant to preserve.
- Evidence: a code path or local reproduction; mark unrun tests honestly.

Place an inline comment only on a valid current PR diff line. If not possible, describe the file and location in the overall review body.
